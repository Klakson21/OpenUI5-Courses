/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"zjblessons/HW2/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"zjblessons/HW2/test/integration/pages/Worklist",
	"zjblessons/HW2/test/integration/pages/Object",
	"zjblessons/HW2/test/integration/pages/NotFound",
	"zjblessons/HW2/test/integration/pages/Browser",
	"zjblessons/HW2/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "zjblessons.HW2.view."
	});

	sap.ui.require([
		"zjblessons/HW2/test/integration/WorklistJourney",
		"zjblessons/HW2/test/integration/ObjectJourney",
		"zjblessons/HW2/test/integration/NavigationJourney",
		"zjblessons/HW2/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});